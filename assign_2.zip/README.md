# Ben Snider, CS162, 10.3.2023
This assignment is already late, so I'll keep this short. 
The file combatant_test.py located in this folder should contain the combatant
class structure as described in my Google doc, then create create a level 1, water type instance
named "Player" within the code. Then, it will ask the user to name "Player".
At LVL 1 all used stats should just be set to 1, except for HP which starts at 10, and PV's 
and XP start at 0. 
After naming the character they will be given the choice between 2 of the 5 possible weapon
types to be their starting weapon, and on deciding they will be given a wooden version
(base attack 1) of that weapon type sent to their inventory. 
The program will then give them the option to 
view their current stats (excluding PV's) and inventory, or to end the program.
