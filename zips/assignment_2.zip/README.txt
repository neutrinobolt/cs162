9.28.23, Ben Snider, project 0

5 things I find interesting:
    1. Game design (I'm not all that interested in making it a carreer, but I do think it's cool)
    2. The role of AI in systems and just society in general I guess
    3. Cyber security (My phone got big time hacked this summer and I had to factory reset it, rather
    that didn't happen again)
    4. Software design and creation processes
    5. UI's

5 things I find challenging
    1. Software design and creation processes
    2. UI's 
    3. Cyber security (as exemplfied above)
    4. Working with a team on a project
    5. I'm stil rather unfamiliar with a lot of the tools used in programming (VS code, Github etc.)

Link to Github repo:
https://github.com/neutrinobolt/cs162