"""Ben Snider, CS 162

Main driver file for assignment 5."""

import rect_search as rs

def main():
    searcher = rs.SearchWindow()
    searcher.mainloop()

if __name__ == "__main__":
    main()
