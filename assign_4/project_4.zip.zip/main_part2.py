
from p2_guis import NumDisplay

def main():
    
    window = NumDisplay()
    window.mainloop()

if __name__ == "__main__":
    main()