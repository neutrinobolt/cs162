Ben Snider, Assignment 3

My part in the project was to design an opening screen and a file select screen
for the yet-to-be-named game. I have successfully created funtions that do each
of these individually, though connecting them together has not happened yet.
Also included in the class library are a few methods for creation of GUI 
elements that may be rather redundant, but could also be helpful in the future
I suppose. 

Since I am the only person in my team that is a real person I'm sad to report 
that the rest of my team members have been woefully slacking. I may be turning 
thisin late, but I have yet to hear any word on their progress at all. So far 
I am the only one in my team that has done any work at all on their part of
the project. 
